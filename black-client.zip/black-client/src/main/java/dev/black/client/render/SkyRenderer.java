package dev.black.client.render;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.black.client.BlackClient;
import dev.black.client.feature.Features;
import dev.black.client.feature.impl.ShaderSkyFeature;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;

/** Шейдерное небо для Atmosphere (порт AmbienceSkyRenderer из skycore). */
public final class SkyRenderer {
	private static final int SLICES = 32, STACKS = 32;
	private static final float RADIUS = 100.0F;
	private static final String[] FILES = {null, "space_sky.glsl", "sky_nebula.glsl", "sky_plasma.glsl", "sky_summer.glsl", "sky_sakura.glsl", "sky_ethereal.glsl"};

	private static final GlProgram[] PROGRAMS = new GlProgram[FILES.length];
	private static final boolean[] TRIED = new boolean[FILES.length];
	private static AutoFramebuffer skyFramebuffer;
	private static boolean disabled;

	private SkyRenderer() {}

	public static boolean shouldReplaceVanillaSky() {
		ShaderSkyFeature a = Features.SHADER_SKY;
		return !disabled && a.enabled && a.mode() > 0 && MinecraftClient.getInstance().world != null;
	}

	public static void render() {
		if (disabled) return;
		RenderSystem.assertOnRenderThread();
		try {
			renderInternal();
		} catch (Throwable t) {
			disabled = true;
			BlackClient.LOG.error("Atmosphere sky disabled after a rendering error", t);
			MinecraftClient.getInstance().getFramebuffer().beginWrite(false);
			GL20.glUseProgram(0);
		}
	}

	private static GlProgram program(int mode) {
		if (!TRIED[mode]) {
			TRIED[mode] = true;
			PROGRAMS[mode] = GlProgram.load(FILES[mode], "vertex.glsl");
		}
		return PROGRAMS[mode];
	}

	private static void renderInternal() {
		MinecraftClient mc = MinecraftClient.getInstance();
		ShaderSkyFeature a = Features.SHADER_SKY;
		GlProgram shader = program(a.mode());
		if (shader == null) return;
		if (skyFramebuffer == null) skyFramebuffer = new AutoFramebuffer(false);

		float[] primary = a.skyColor(1.0F);
		float[] secondary = a.skyColor(0.65F);

		int width = Math.max(1, mc.getFramebuffer().textureWidth);
		int height = Math.max(1, mc.getFramebuffer().textureHeight);
		skyFramebuffer.resizeTo(width, height);
		skyFramebuffer.setup(true);

		boolean night = a.mode() == 4 && a.summerNight.value;
		float time = System.currentTimeMillis() % 100000L / 1000.0F * (float) a.speed.value;

		shader.use();
		shader.setVec4("u_Color", primary[0], primary[1], primary[2], 1.0F);
		shader.setVec3("u_Color2", secondary[0], secondary[1], secondary[2]);
		shader.setFloat("u_Scale", (float) a.scale.value);
		shader.setFloat("u_Time", time);
		shader.setFloat("u_Night", night ? 1.0F : 0.0F);
		shader.setMatrix4f("Transform", PostFx.transform(width, height));

		GL13.glActiveTexture(GL13.GL_TEXTURE0);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, 0);
		PostFx.drawQuad(width, height, false);
		shader.stop();
		skyFramebuffer.stop();
		mc.getFramebuffer().beginWrite(false);

		RenderSystem.depthMask(false);
		RenderSystem.enableBlend();
		RenderSystem.disableCull();
		RenderSystem.disableDepthTest();
		RenderSystem.defaultBlendFunc();

		RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
		RenderSystem.setShaderTexture(0, skyFramebuffer.getColorAttachment());
		drawSphere(new Matrix4f());

		RenderSystem.enableCull();
		RenderSystem.enableDepthTest();
		RenderSystem.depthMask(true);
		RenderSystem.disableBlend();
		GL20.glUseProgram(0);
		RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
		RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
	}

	private static void drawSphere(Matrix4f matrix) {
		BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
		for (int stack = 0; stack < STACKS; stack++) {
			float theta = 3.1415927F * stack / STACKS;
			float nextTheta = 3.1415927F * (stack + 1) / STACKS;
			float sinT = (float) Math.sin(theta), cosT = (float) Math.cos(theta);
			float nSinT = (float) Math.sin(nextTheta), nCosT = (float) Math.cos(nextTheta);
			float v = (float) stack / STACKS, nv = (float) (stack + 1) / STACKS;
			for (int slice = 0; slice < SLICES; slice++) {
				float phi = 6.2831855F * slice / SLICES;
				float nextPhi = 6.2831855F * (slice + 1) / SLICES;
				float sinP = (float) Math.sin(phi), cosP = (float) Math.cos(phi);
				float nSinP = (float) Math.sin(nextPhi), nCosP = (float) Math.cos(nextPhi);
				float u = (float) slice / SLICES, nu = (float) (slice + 1) / SLICES;
				vertex(buffer, matrix, sinT, cosT, sinP, cosP, u, v);
				vertex(buffer, matrix, nSinT, nCosT, sinP, cosP, u, nv);
				vertex(buffer, matrix, nSinT, nCosT, nSinP, nCosP, nu, nv);
				vertex(buffer, matrix, sinT, cosT, nSinP, nCosP, nu, v);
			}
		}
		BufferRenderer.drawWithGlobalProgram(buffer.end());
	}

	private static void vertex(BufferBuilder buffer, Matrix4f matrix, float sinT, float cosT, float sinP, float cosP, float u, float v) {
		buffer.vertex(matrix, RADIUS * sinT * cosP, RADIUS * cosT, RADIUS * sinT * sinP).texture(u, v).color(255, 255, 255, 255);
	}
}
