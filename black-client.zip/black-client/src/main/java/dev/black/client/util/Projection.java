package dev.black.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/** Проекция мировых координат на экран (в масштабированных GUI-пикселях). */
public final class Projection {
	/** Вертикальный FOV последнего кадра мира (обновляется в GameRendererMixin). */
	public static float lastFov = 70f;
	/** Множитель по X, если включён AspectRatio (обновляется в GameRendererMixin). */
	public static float aspectScale = 1f;

	private Projection() {}

	public record P(double x, double y, boolean front, double dirX, double dirY) {}

	public static P project(MinecraftClient mc, Vec3d world) {
		Camera cam = mc.gameRenderer.getCamera();
		Vec3d d = world.subtract(cam.getPos());
		double yaw = Math.toRadians(cam.getYaw());
		double pitch = Math.toRadians(cam.getPitch());
		double sy = Math.sin(yaw), cy = Math.cos(yaw), sp = Math.sin(pitch), cp = Math.cos(pitch);

		double xc = d.x * -cy + d.z * -sy;                       // вправо
		double yc = d.x * (-sy * sp) + d.y * cp + d.z * (cy * sp); // вверх
		double zc = d.x * (-sy * cp) + d.y * -sp + d.z * (cy * cp); // вперёд

		double len = Math.hypot(xc, yc);
		double dx = len > 1e-6 ? xc / len : 0, dy = len > 1e-6 ? -yc / len : -1;

		if (zc <= 0.05) return new P(Double.NaN, Double.NaN, false, dx, dy);

		int w = mc.getWindow().getScaledWidth(), h = mc.getWindow().getScaledHeight();
		double scale = (h / 2.0) / Math.tan(Math.toRadians(lastFov) / 2.0);
		return new P(w / 2.0 + xc / zc * scale * aspectScale, h / 2.0 - yc / zc * scale, true, dx, dy);
	}

	/** Экранные границы бокса {minX, minY, maxX, maxY} или null, если часть бокса за камерой / вне экрана. */
	public static double[] bounds(MinecraftClient mc, Box b) {
		double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
		for (int i = 0; i < 8; i++) {
			double x = (i & 1) == 0 ? b.minX : b.maxX;
			double y = (i & 2) == 0 ? b.minY : b.maxY;
			double z = (i & 4) == 0 ? b.minZ : b.maxZ;
			P p = project(mc, new Vec3d(x, y, z));
			if (!p.front()) return null;
			minX = Math.min(minX, p.x());
			minY = Math.min(minY, p.y());
			maxX = Math.max(maxX, p.x());
			maxY = Math.max(maxY, p.y());
		}
		int w = mc.getWindow().getScaledWidth(), h = mc.getWindow().getScaledHeight();
		if (maxX < 0 || maxY < 0 || minX > w || minY > h) return null;
		return new double[]{minX, minY, maxX, maxY};
	}
}
