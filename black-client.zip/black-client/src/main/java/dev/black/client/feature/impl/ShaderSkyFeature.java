package dev.black.client.feature.impl;

import dev.black.client.feature.Category;
import dev.black.client.feature.Feature;
import dev.black.client.feature.setting.BoolSetting;
import dev.black.client.feature.setting.NumSetting;
import dev.black.client.gui.Gfx;
import net.minecraft.client.MinecraftClient;

/** Шейдерное небо (Cosmos, Nebula, Plasma, Summer, Sakura, Ethereal) и свой туман. */
public class ShaderSkyFeature extends Feature {
	public final NumSetting sky = add(new NumSetting("Sky", 1, 0, 6, 1, "")
		.labels("Default", "Cosmos", "Nebula", "Plasma", "Summer", "Sakura", "Ethereal"));
	public final BoolSetting summerNight = add(new BoolSetting("Summer: night", false));
	public final NumSetting speed = add(new NumSetting("Shader speed", 1.2, 0.1, 5.0, 0.1, "x"));
	public final NumSetting scale = add(new NumSetting("Shader scale", 1.0, 0.2, 4.0, 0.1, "x"));
	public final NumSetting colorMode = add(new NumSetting("Sky color", 0, 0, 1, 1, "").labels("Theme", "Custom"));
	public final NumSetting hue = add(new NumSetting("Sky hue", 270, 0, 360, 5, "°").asHue());
	public final NumSetting sat = add(new NumSetting("Sky saturation", 0.8, 0.0, 1.0, 0.05, ""));
	public final NumSetting fog = add(new NumSetting("Fog", 0, 0, 2, 1, "").labels("Vanilla", "Clear", "Custom"));
	public final NumSetting fogHue = add(new NumSetting("Fog hue", 210, 0, 360, 5, "°").asHue());
	public final NumSetting fogBright = add(new NumSetting("Fog brightness", 0.6, 0.0, 1.0, 0.05, ""));
	public final NumSetting fogStart = add(new NumSetting("Fog start", 0.5, 0.1, 1.5, 0.1, ""));
	public final NumSetting fogEnd = add(new NumSetting("Fog end", 1.0, 0.1, 1.5, 0.1, ""));

	public ShaderSkyFeature() {
		super("Shader Sky", "Animated shader sky and custom fog", Category.VISUAL);
	}

	public int mode() {
		return (int) Math.round(sky.value);
	}

	public int fogMode() {
		return (int) Math.round(fog.value);
	}

	/** Цвет неба (RGB 0..1), умноженный на factor. */
	public float[] skyColor(float factor) {
		int rgb = colorMode.value > 0.5
			? Gfx.hsb((float) (hue.value / 360.0), (float) sat.value, 1f)
			: Gfx.accentA();
		return new float[]{
			((rgb >> 16) & 255) / 255.0F * factor,
			((rgb >> 8) & 255) / 255.0F * factor,
			(rgb & 255) / 255.0F * factor
		};
	}

	public int fogColorArgb() {
		return 0xFF000000 | (Gfx.hsb((float) (fogHue.value / 360.0), 0.55f, (float) fogBright.value) & 0xFFFFFF);
	}

	@Override
	public void onTick(MinecraftClient mc) {
		// Summer: фиксированное время суток, чтобы небо совпадало с миром
		if (enabled && mc.world != null && mode() == 4) {
			mc.world.getLevelProperties().setTimeOfDay(summerNight.value ? 18000L : 6000L);
		}
	}
}
