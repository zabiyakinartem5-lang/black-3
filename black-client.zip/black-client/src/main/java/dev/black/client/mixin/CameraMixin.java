package dev.black.client.mixin;

import dev.black.client.feature.Features;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(Camera.class)
public abstract class CameraMixin {
	// Подменяем первый вызов setRotation в update(): камера считает позицию уже с нашими углами.
	@Redirect(
		method = "update",
		at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;setRotation(FF)V", ordinal = 0)
	)
	private void black$freelookRotation(Camera camera, float yaw, float pitch) {
		if (Features.FREELOOK.isLooking()) {
			((CameraInvoker) camera).black$setRotation(Features.FREELOOK.yaw, Features.FREELOOK.pitch);
		} else {
			((CameraInvoker) camera).black$setRotation(yaw, pitch);
		}
	}
}
