package dev.black.client.feature.impl;

import dev.black.client.feature.Category;
import dev.black.client.feature.Feature;
import dev.black.client.feature.setting.NumSetting;
import dev.black.client.gui.Gfx;
import dev.black.client.util.Projection;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.TntEntity;

import java.util.Locale;

/** Таймер до взрыва над активированным TNT. */
public class TntTimerFeature extends Feature {
	public final NumSetting maxDistance = add(new NumSetting("Distance", 64, 8, 256, 8, "m"));
	public final NumSetting scale = add(new NumSetting("Scale", 1.0, 0.5, 2.0, 0.1, "x"));

	public TntTimerFeature() {
		super("TNT Timer", "Fuse countdown above primed TNT", Category.VISUAL);
	}

	public void draw(DrawContext c, MinecraftClient mc, float td) {
		if (!enabled || mc.world == null || mc.player == null) return;
		var tr = mc.textRenderer;
		for (Entity e : mc.world.getEntities()) {
			if (!(e instanceof TntEntity tnt)) continue;
			if (mc.player.distanceTo(e) > maxDistance.value) continue;
			Projection.P p = Projection.project(mc, e.getLerpedPos(td).add(0, e.getHeight() + 0.4, 0));
			if (!p.front()) continue;

			float sec = Math.max(0, tnt.getFuse()) / 20f;
			String text = String.format(Locale.ROOT, "%.1fs", sec);
			int col = Gfx.lerp(0xFFFF4040, 0xFFFFE070, Math.min(1f, sec / 4f));
			MatrixStack m = c.getMatrices();
			m.push();
			m.translate((float) p.x(), (float) p.y(), 0f);
			float s = (float) scale.value;
			m.scale(s, s, 1f);
			int w = tr.getWidth(text);
			c.fill(-w / 2 - 3, -2, w / 2 + 3, 10, 0x90000000);
			c.drawText(tr, text, -w / 2, 0, col, true);
			m.pop();
		}
	}
}
