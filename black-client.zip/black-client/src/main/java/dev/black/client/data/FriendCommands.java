package dev.black.client.data;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.hit.EntityHitResult;

import java.util.List;
import java.util.Locale;

/** Чат-команды: .friend add|remove|toggle|list|clear [ник]  (псевдоним .f). Команда на сервер не уходит. */
public final class FriendCommands {
	private FriendCommands() {}

	public static void info(String message) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.inGameHud != null) {
			mc.inGameHud.getChatHud().addMessage(Text.literal("§7[§fBlack§7] §7" + message));
		}
	}

	/** @return true, если сообщение было командой и его не нужно отправлять. */
	public static boolean handle(String message) {
		String m = message.trim();
		String lower = m.toLowerCase(Locale.ROOT);
		if (!(lower.equals(".friend") || lower.startsWith(".friend ") || lower.equals(".f") || lower.startsWith(".f "))) return false;
		String[] parts = m.split("\\s+");
		String action = parts.length > 1 ? parts[1].toLowerCase(Locale.ROOT) : "list";
		String name = parts.length > 2 ? parts[2] : lookedAtPlayer();

		switch (action) {
			case "add" -> {
				if (name == null) info("Usage: .friend add <name>  (or look at a player)");
				else if (Friends.add(name)) info("§f" + name + "§7 added to friends");
				else info("§f" + name + "§7 is already a friend");
			}
			case "remove", "del" -> {
				if (name == null) info("Usage: .friend remove <name>");
				else if (Friends.has(name)) {
					Friends.remove(name);
					info("§f" + name + "§7 removed from friends");
				} else info("§f" + name + "§7 is not a friend");
			}
			case "toggle" -> {
				if (name == null) info("Look at a player or use .friend toggle <name>");
				else if (Friends.has(name)) {
					Friends.remove(name);
					info("§f" + name + "§7 removed from friends");
				} else {
					Friends.add(name);
					info("§f" + name + "§7 added to friends");
				}
			}
			case "clear" -> {
				for (String n : Friends.all()) Friends.remove(n);
				info("Friends list cleared");
			}
			default -> {
				List<String> all = Friends.all();
				info(all.isEmpty() ? "No friends yet. .friend add <name>"
					: "Friends (" + all.size() + "): §f" + String.join("§7, §f", all));
			}
		}
		return true;
	}

	public static String lookedAtPlayer() {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() instanceof PlayerEntity p) {
			return p.getName().getString();
		}
		return null;
	}
}
