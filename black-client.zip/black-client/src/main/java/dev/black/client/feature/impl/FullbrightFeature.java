package dev.black.client.feature.impl;

import dev.black.client.feature.Category;
import dev.black.client.feature.Feature;

public class FullbrightFeature extends Feature {
	public FullbrightFeature() {
		super("Fullbright", "Maximum brightness everywhere", Category.VISUAL);
	}
}
