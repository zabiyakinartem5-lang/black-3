package dev.black.client;

import dev.black.client.data.Friends;
import dev.black.client.data.Waypoints;
import dev.black.client.feature.Feature;
import dev.black.client.feature.Features;
import dev.black.client.gui.ClickGui;
import dev.black.client.gui.HudRenderer;
import dev.black.client.render.MotionBlurRenderer;
import net.fabricmc.api.ClientModInitializer;
import dev.black.client.pvp.PvpStats;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.util.ActionResult;
import net.minecraft.client.MinecraftClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BlackClient implements ClientModInitializer {
	public static final Logger LOG = LoggerFactory.getLogger("blackclient");
	/** Время запуска клиента (для счётчика времени игры). */
	public static final long START = System.currentTimeMillis();

	private static int autosaveTicks;

	@Override
	public void onInitializeClient() {
		Config.load();
		Friends.load();
		Waypoints.load();

		ClientTickEvents.END_CLIENT_TICK.register(mc -> {
			if (Keys.pressedOnce(Keys.gui()) && mc.currentScreen == null) mc.setScreen(new ClickGui());
			int hudKey = Features.KEYBINDS.toggleHud.key;
			if (hudKey > 0 && mc.currentScreen == null && mc.player != null && Keys.pressedOnce(hudKey)) {
				HudRenderer.hidden = !HudRenderer.hidden;
			}
			int cpKey = Features.KEYBINDS.copyCoords.key;
			if (cpKey > 0 && mc.currentScreen == null && mc.player != null && Keys.pressedOnce(cpKey)) {
				mc.keyboard.setClipboard(mc.player.getBlockX() + " " + mc.player.getBlockY() + " " + mc.player.getBlockZ());
				dev.black.client.gui.Toasts.push("Coordinates copied", 0xFF4ADE80);
			}
			// автосохранение настроек раз в ~60 секунд
			if (++autosaveTicks >= 1200) {
				autosaveTicks = 0;
				Config.save();
			}
			for (Feature f : Features.ALL) {
				// клавиша модуля, назначенная в меню
				if (!f.alwaysOn && f.bind.key > 0 && Keys.pressedOnce(f.bind.key) && mc.currentScreen == null && mc.player != null) {
					f.toggle();
				}
				f.onTick(mc);
			}
			PvpStats.tick(mc);
		});

		HudRenderCallback.EVENT.register((context, tickCounter) -> {
			Features.ZOOM.update();
			MinecraftClient mcl = MinecraftClient.getInstance();
			HudRenderer.render(context, mcl);
			if (mcl.player != null && !HudRenderer.hidden) {
				Features.TNT_TIMER.draw(context, mcl, tickCounter.getTickDelta(false));
				Features.HIT_MARKER.draw(context, mcl);
			}
		});

		// только запоминаем удар для статистики; сам удар не меняем и не отменяем
		AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
			if (world.isClient) {
				PvpStats.onAttack(player, entity);
				Features.HIT_MARKER.hit(entity);
			}
			return ActionResult.PASS;
		});

		WorldRenderEvents.END.register(context -> MotionBlurRenderer.apply(MinecraftClient.getInstance()));

		net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents.ALLOW_CHAT.register(
			message -> !dev.black.client.data.FriendCommands.handle(message));

		ClientLifecycleEvents.CLIENT_STOPPING.register(client -> Config.save());

		LOG.info("Black Client загружен. Меню: Right Shift.");
	}
}
