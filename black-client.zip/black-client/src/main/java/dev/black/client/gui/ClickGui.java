package dev.black.client.gui;

import dev.black.client.Config;
import dev.black.client.data.Friends;
import dev.black.client.data.Profiles;
import dev.black.client.data.Waypoints;
import dev.black.client.feature.Category;
import dev.black.client.feature.Feature;
import dev.black.client.feature.Features;
import dev.black.client.feature.setting.BindSetting;
import dev.black.client.feature.setting.BoolSetting;
import dev.black.client.feature.setting.NumSetting;
import dev.black.client.feature.setting.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * Меню Black Client: отдельная вытянутая вертикальная панель на каждую вкладку.
 * Анимации: каскадное появление панелей, параллакс, свечение панели под курсором, блик в заголовке,
 * волна при клике, вспышка строки, плавное сворачивание панелей, частицы и шары на фоне, плавное закрытие.
 */
public class ClickGui extends Screen {
	private static final int HEADER_H = 24;
	private static final int ROW_H = 20;
	private static final int ENTRY_H = 24;
	private static final int INPUT_H = 22;
	private static final int GAP = 6;
	private static final int TOP = 30;
	private static final int BOTTOM = 34;

	private static final Category[] CATS = Category.values();
	private static final int N = CATS.length;

	/** Состояние, которое запоминается между открытиями. */
	private static final float[] SCROLL = new float[N];
	private static final boolean[] COLLAPSED = new boolean[N];
	private static float panOff;

	private record Hit(int x, int y, int w, int h, Runnable left, Runnable right, NumSetting slider) {
		boolean contains(double mx, double my) {
			return mx >= x && mx < x + w && my >= y && my < y + h;
		}
	}

	private record Entry(String title, String sub, int dot, String actLabel, Runnable act, Runnable remove) {}

	private static final class Ripple {
		final int panel;
		final float x, y;
		float age;

		Ripple(int panel, float x, float y) {
			this.panel = panel;
			this.x = x;
			this.y = y;
		}
	}

	private final List<Hit> hits = new ArrayList<>();
	private final List<Ripple> ripples = new ArrayList<>();
	private final Map<Feature, Float> flash = new IdentityHashMap<>();
	private final Map<String, Float> btnHover = new java.util.HashMap<>();
	private final Map<Category, TextFieldWidget> inputs = new java.util.EnumMap<>(Category.class);

	private final float[] scrollAnim = new float[N];
	private final float[] collapseAnim = new float[N];
	private final float[] glow = new float[N];
	private final float[] countAnim = new float[N];
	private final float[] barFade = new float[N];
	private final int[] pX = new int[N], pY = new int[N], pW = new int[N], pH = new int[N];
	private final float[] viewTop = new float[N], viewBot = new float[N], maxScroll = new float[N];

	private float open;
	private boolean closing;
	private long last = System.nanoTime();
	private final long born = System.nanoTime();
	private float dtFrame;
	private float hoverFade;

	private BindSetting listening;
	private NumSetting dragging;
	private Hit dragHit;
	private String hoverDesc;
	private int mouseX, mouseY;

	private TextFieldWidget search;
	private List<String> profileCache = new ArrayList<>();
	private String status = "";
	private long statusUntil;

	// частицы фона
	private static final int PARTS = 46;
	private final float[] ptx = new float[PARTS], pty = new float[PARTS], pts = new float[PARTS], ptp = new float[PARTS];

	public ClickGui() {
		super(Text.literal("Black Client"));
		for (int i = 0; i < N; i++) {
			scrollAnim[i] = SCROLL[i];
			collapseAnim[i] = COLLAPSED[i] ? 0f : 1f;
		}
		Random r = new Random(7);
		for (int i = 0; i < PARTS; i++) {
			ptx[i] = r.nextFloat();
			pty[i] = r.nextFloat();
			pts[i] = 0.01f + r.nextFloat() * 0.03f;
			ptp[i] = r.nextFloat() * 6.28f;
		}
	}

	@Override
	protected void init() {
		for (Category cat : CATS) {
			if (!cat.isCustom()) continue;
			TextFieldWidget f = new TextFieldWidget(textRenderer, 0, 0, 80, 14, Text.empty());
			f.setMaxLength(24);
			f.setVisible(false);
			addSelectableChild(f);
			inputs.put(cat, f);
		}
		search = new TextFieldWidget(textRenderer, 0, 0, 110, 14, Text.empty());
		search.setMaxLength(20);
		search.setPlaceholder(Text.literal("Поиск (/)"));
		addSelectableChild(search);
		refreshProfiles();
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	/** Закрытие с анимацией: панели уезжают, потом экран закрывается. */
	@Override
	public void close() {
		if (closing) return;
		closing = true;
		Config.save();
	}

	private void setStatus(String s) {
		status = s;
		statusUntil = System.currentTimeMillis() + 3000;
	}

	private void refreshProfiles() {
		profileCache = Profiles.list();
	}

	private boolean searching() {
		return search != null && !search.getText().trim().isEmpty();
	}

	private static float back(float t) {
		t = Math.max(0f, Math.min(1f, t));
		float c1 = 1.25f, c3 = c1 + 1f;
		return 1f + c3 * (float) Math.pow(t - 1f, 3) + c1 * (float) Math.pow(t - 1f, 2);
	}

	private static float clamp01(float v) {
		return Math.max(0f, Math.min(1f, v));
	}

	// ------------------------------------------------------------------ render

	@Override
	public void render(DrawContext c, int mx, int my, float delta) {
		long now = System.nanoTime();
		float dt = Math.min(0.1f, (now - last) / 1_000_000_000f);
		last = now;
		dtFrame = dt;
		float t = (now - born) / 1_000_000_000f;
		float speed = Gfx.animMul();
		open = closing ? Math.max(0f, open - dt * 3.2f * speed) : Math.min(1f, open + dt * 2.6f * speed);
		if (closing && open <= 0f) {
			if (client != null) client.setScreen(null);
			return;
		}
		mouseX = mx;
		mouseY = my;
		hits.clear();
		hoverDesc = null;
		float e = Gfx.easeOut(open);
		float k = Gfx.animK(dt, 14f);

		drawBackdrop(c, e, t);
		drawTopBar(c, e, t);

		// раскладка панелей
		int avail = width - 16;
		int pw = Math.max(92, Math.min(124, (avail - GAP * (N - 1)) / N));
		int totalW = N * pw + GAP * (N - 1);
		int startX;
		if (totalW <= width - 8) {
			startX = (width - totalW) / 2;
			panOff = 0f;
		} else {
			float minPan = (width - 8) - totalW - 8;
			panOff = Math.max(minPan, Math.min(0f, panOff));
			startX = 8 + (int) panOff;
		}
		int ph = Math.max(120, height - TOP - BOTTOM);
		float parX = (0.5f - mx / (float) Math.max(1, width)) * 8f;
		float parY = (0.5f - my / (float) Math.max(1, height)) * 4f;

		for (int i = 0; i < N; i++) {
			float local = clamp01(open * (1f + N * 0.10f) - i * 0.10f);
			float prog = closing ? Gfx.easeOut(local) : back(local);
			float depth = 0.6f + 0.2f * (i % 3);
			pW[i] = pw;
			pX[i] = startX + i * (pw + GAP) + (int) (parX * depth);
			pY[i] = TOP + (int) ((1f - prog) * 46f) + (int) (parY * depth);
			pH[i] = ph;
			drawPanel(c, i, clamp01(local * 1.4f) * e, k, dt, t);
		}

		drawBottomBar(c, e);
		drawRipples(c, dt);

		if (hoverDesc != null && !hoverDesc.isEmpty() && dragging == null) {
			hoverFade = Math.min(1f, hoverFade + dt * 8f);
		} else {
			hoverFade = Math.max(0f, hoverFade - dt * 10f);
		}
		if (hoverFade > 0.02f && hoverDesc != null) {
			int tw = textRenderer.getWidth(hoverDesc);
			int tx = Math.min(mx + 10, width - tw - 8);
			int ty = Math.min(my + 12 - (int) ((1f - hoverFade) * 4f), height - 16);
			Gfx.rrect(c, tx - 4, ty - 3, tw + 8, 14, 4, Gfx.withAlpha(0xFF0B0B14, hoverFade * 0.95f));
			c.drawText(textRenderer, hoverDesc, tx, ty, Gfx.withAlpha(Gfx.text(), hoverFade), true);
		}
	}

	// ---- фон

	private void drawBackdrop(DrawContext c, float e, float t) {
		c.fillGradient(0, 0, width, height, Gfx.withAlpha(0xCC05050C, e), Gfx.withAlpha(Gfx.lerp(0xCC05050C, Gfx.accentA() | 0xFF000000, 0.22f), e));
		float s = Math.min(width, height);
		orb(c, width * (0.2f + 0.1f * (float) Math.sin(t * 0.3f)), height * (0.3f + 0.1f * (float) Math.cos(t * 0.25f)), s * 0.35f, Gfx.accentA(), 0.05f * e);
		orb(c, width * (0.8f + 0.08f * (float) Math.cos(t * 0.27f)), height * (0.7f + 0.1f * (float) Math.sin(t * 0.33f)), s * 0.32f, Gfx.accentB(), 0.05f * e);
		for (int i = 0; i < PARTS; i++) {
			pty[i] -= pts[i] * dtFrame;
			ptx[i] += (float) Math.sin(t * 0.6f + ptp[i]) * 0.004f * dtFrame * 10f;
			if (pty[i] < -0.02f) {
				pty[i] = 1.02f;
				ptx[i] = (ptx[i] + 0.37f) % 1f;
			}
			float tw = 0.5f + 0.5f * (float) Math.sin(t * 1.6f + ptp[i]);
			int col = Gfx.withAlpha(i % 2 == 0 ? Gfx.accentA() : Gfx.accentB(), e * (0.15f + 0.4f * tw));
			int px = (int) (ptx[i] * width), py = (int) (pty[i] * height);
			int sz = i % 5 == 0 ? 2 : 1;
			c.fill(px, py, px + sz, py + sz, col);
		}
	}

	private void orb(DrawContext c, float cx, float cy, float r, int color, float alpha) {
		for (int i = 0; i < 6; i++) {
			float rr = r * (1f - i / 6f);
			int a = Math.max(2, (int) (alpha * 255f));
			int rgb = color & 0xFFFFFF;
			int ri = (int) rr;
			for (int dy = -ri; dy < ri; dy += 3) {
				double half = Math.sqrt(Math.max(0, (double) rr * rr - (double) dy * dy));
				c.fill((int) (cx - half), (int) cy + dy, (int) (cx + half), (int) cy + dy + 3, (a << 24) | rgb);
			}
		}
	}

	// ---- верхняя и нижняя панели

	private void drawTopBar(DrawContext c, float e, float t) {
		String a = "Black", b = " Client";
		int lx = 12, ly = 9 - (int) ((1f - e) * 8f);
		// блик пробегает по названию
		c.drawText(textRenderer, a, lx, ly, Gfx.withAlpha(Gfx.accentA(), e), true);
		c.drawText(textRenderer, b, lx + textRenderer.getWidth(a), ly, Gfx.withAlpha(Gfx.text(), e), true);
		int lw = textRenderer.getWidth(a + b);
		float sh = (t * 0.5f) % 2f;
		if (sh < 1f) {
			int sx = lx + (int) (lw * sh);
			c.fill(sx, ly - 1, sx + 3, ly + 9, Gfx.withAlpha(0xFFFFFFFF, e * 0.22f * (1f - Math.abs(sh - 0.5f) * 2f)));
		}

		int sw = 130;
		int sx = (width - sw) / 2;
		boolean focused = search.isFocused();
		Gfx.rrect(c, sx - 3, 5, sw + 6, 20, 7, Gfx.withAlpha(focused ? Gfx.accentA() : Gfx.header(), e * (focused ? 0.8f : 0.9f)));
		search.setX(sx + 2);
		search.setY(8);
		search.setWidth(sw - 4);
		search.render(c, mouseX, mouseY, 0f);
	}

	private void drawBottomBar(DrawContext c, float e) {
		int by = height - BOTTOM + 8 + (int) ((1f - e) * 14f);
		int bw = 70, bh = 16;
		int total = bw * 2 + 6;
		int bx = (width - total) / 2;
		button(c, bx, by, bw, bh, "Edit HUD", e, () -> {
			Config.save();
			client.setScreen(new HudEditor());
		});
		button(c, bx + bw + 6, by, bw, bh, "Close", e, this::close);

		boolean showStatus = System.currentTimeMillis() < statusUntil;
		String line = showStatus ? status : "ЛКМ — вкл/выкл · ПКМ — настройки · колесо — прокрутка · / — поиск · клик по заголовку — свернуть";
		c.drawText(textRenderer, line, (width - textRenderer.getWidth(line)) / 2, by + 20,
			Gfx.withAlpha(showStatus ? Gfx.accentB() : Gfx.textDim(), e), true);
	}

	private void button(DrawContext c, int x, int y, int w, int h, String text, float e, Runnable action) {
		boolean hover = mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
		float ha = btnHover.getOrDefault(text, 0f);
		ha += ((hover ? 1f : 0f) - ha) * Gfx.animK(dtFrame, 18f);
		btnHover.put(text, ha);
		int grow = (int) (ha * 2f);
		Gfx.rrect(c, x - grow, y - grow, w + grow * 2, h + grow * 2, 6, Gfx.withAlpha(Gfx.lerp(Gfx.header(), Gfx.accentA(), ha), e));
		c.drawText(textRenderer, text, x + (w - textRenderer.getWidth(text)) / 2, y + 4, Gfx.withAlpha(Gfx.text(), e), true);
		hits.add(new Hit(x, y, w, h, action, null, null));
	}

	// ------------------------------------------------------------------ panels

	private List<Feature> visible(Category cat) {
		List<Feature> list = new ArrayList<>();
		String q = searching() ? search.getText().trim().toLowerCase(Locale.ROOT) : null;
		for (Feature f : Features.ALL) {
			if (f.category != cat) continue;
			if (q != null && !(f.name.toLowerCase(Locale.ROOT).contains(q) || f.description.toLowerCase(Locale.ROOT).contains(q))) continue;
			list.add(f);
		}
		return list;
	}

	private float settingsHeight(Feature f) {
		float h = 0;
		for (Setting s : f.settings) h += s.height();
		return h + (f.settings.isEmpty() ? 0 : 3);
	}

	private String fit(String s, int maxW) {
		if (maxW <= 6) return "";
		if (textRenderer.getWidth(s) <= maxW) return s;
		return textRenderer.trimToWidth(s, maxW - textRenderer.getWidth("..")) + "..";
	}

	private void drawPanel(DrawContext c, int i, float e, float k, float dt, float t) {
		Category cat = CATS[i];
		int x = pX[i], y = pY[i], w = pW[i], fullH = pH[i];
		List<Feature> features = visible(cat);
		boolean searchOn = searching();
		boolean custom = cat.isCustom() && !searchOn;
		List<Entry> entries = custom ? entries(cat) : List.of();

		collapseAnim[i] += ((COLLAPSED[i] ? 0f : 1f) - collapseAnim[i]) * Gfx.animK(dt, 12f);
		float ca = Gfx.easeOut(collapseAnim[i]);
		int h = (int) (HEADER_H + 4 + (fullH - HEADER_H - 4) * ca);

		boolean hover = mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
		glow[i] += ((hover ? 1f : 0f) - glow[i]) * Gfx.animK(dt, 10f);
		float dim = searchOn && features.isEmpty() ? 0.35f : 1f;
		float ea = e * dim;

		// тень, свечение и корпус
		Gfx.rrect(c, x - 2, y - 1, w + 4, h + 4, 10, Gfx.withAlpha(0x50000000, ea));
		if (glow[i] > 0.02f) {
			Gfx.rrect(c, x - 1, y - 1, w + 2, h + 2, 9, Gfx.withAlpha(Gfx.lerp(Gfx.accentA(), Gfx.accentB(), 0.5f), ea * glow[i] * 0.75f));
		}
		Gfx.rrect(c, x, y, w, h, 8, Gfx.withAlpha(Gfx.panel(), ea));

		// заголовок: градиентная полоска, блик, бейдж со счётчиком
		Gfx.rrect(c, x, y, w, HEADER_H, 8, Gfx.withAlpha(Gfx.header(), ea));
		c.fill(x, y + HEADER_H - 8, x + w, y + HEADER_H, Gfx.withAlpha(Gfx.header(), ea));
		Gfx.gradientBar(c, x + 6, y + HEADER_H - 2, w - 12, 2, ea);
		float sh = ((t * 0.35f) + i * 0.17f) % 1.6f;
		if (sh < 1f) {
			int sx = x + 6 + (int) ((w - 18) * sh);
			c.fill(sx, y + HEADER_H - 2, sx + 8, y + HEADER_H, Gfx.withAlpha(0xFFFFFFFF, ea * 0.7f));
		}
		c.drawText(textRenderer, cat.label, x + 8, y + 8, Gfx.withAlpha(Gfx.text(), ea), true);

		int on = 0, total = 0;
		for (Feature f : Features.ALL) {
			if (f.category != cat || f.alwaysOn) continue;
			total++;
			if (f.enabled) on++;
		}
		countAnim[i] += (on - countAnim[i]) * Gfx.animK(dt, 10f);
		if (total > 0) {
			String badge = Math.round(countAnim[i]) + "/" + total;
			int bw = textRenderer.getWidth(badge) + 8;
			int bx = x + w - bw - 18;
			Gfx.rrect(c, bx, y + 6, bw, 12, 5, Gfx.withAlpha(Gfx.lerp(Gfx.OFF, Gfx.accentA(), on / (float) Math.max(1, total)), ea * 0.85f));
			c.drawText(textRenderer, badge, bx + 4, y + 8, Gfx.withAlpha(0xFFFFFFFF, ea), false);
		}
		drawChevron(c, x + w - 12, y + 12, ca, ea);
		hits.add(new Hit(x, y, w, HEADER_H, () -> {
			COLLAPSED[i] = !COLLAPSED[i];
			ripples.add(new Ripple(i, mouseX, mouseY));
		}, null, null));

		if (h <= HEADER_H + 6) return;

		// область списка
		int listTop = y + HEADER_H + 3;
		int listBottom = y + h - 4;
		float viewH = listBottom - listTop;
		viewTop[i] = listTop;
		viewBot[i] = listBottom;

		float contentH = 0;
		for (Feature f : features) {
			f.expandAnim += ((f.expanded ? 1f : 0f) - f.expandAnim) * k;
			contentH += ROW_H + settingsHeight(f) * f.expandAnim;
		}
		if (custom) contentH += INPUT_H + (entries.isEmpty() ? 18 : entries.size() * ENTRY_H) + 4;
		float maxS = Math.max(0f, contentH - viewH);
		maxScroll[i] = maxS;
		SCROLL[i] = Math.max(0f, Math.min(maxS, SCROLL[i]));
		scrollAnim[i] += (SCROLL[i] - scrollAnim[i]) * Gfx.animK(dt, 16f);

		c.enableScissor(x + 1, listTop, x + w - 1, listBottom);
		float cy = listTop - scrollAnim[i];
		int idx = 0;
		for (Feature f : features) {
			f.anim += ((f.enabled ? 1f : 0f) - f.anim) * k;
			float rowIn = clamp01(open * 1.8f - 0.3f - Math.min(idx, 14) * 0.045f);
			float rowE = ea * rowIn;
			int slide = (int) ((1f - Gfx.easeOut(rowIn)) * 14f);
			drawFeatureRow(c, i, f, x, (int) cy, w, rowE, slide, listTop, listBottom);
			cy += ROW_H;

			float sh2 = settingsHeight(f) * f.expandAnim;
			if (sh2 > 0.5f) {
				c.enableScissor(x + 1, Math.max(listTop, (int) cy), x + w - 1, Math.min(listBottom, (int) (cy + sh2)));
				float sy = cy;
				boolean interactive = f.expandAnim > 0.9f && f.expanded;
				int si = 0;
				for (Setting s : f.settings) {
					float sIn = clamp01(f.expandAnim * 1.6f - si * 0.12f);
					drawSetting(c, i, s, x, w, (int) sy, rowE * sIn, interactive, listTop, listBottom);
					sy += s.height();
					si++;
				}
				c.disableScissor();
			}
			cy += sh2;
			idx++;
		}
		if (features.isEmpty() && !custom) {
			c.drawText(textRenderer, "Ничего нет", x + 10, listTop + 6, Gfx.withAlpha(Gfx.textDim(), ea), true);
		}
		if (custom) drawCustom(c, i, cat, x, w, cy, entries, ea, listTop, listBottom);
		else {
			TextFieldWidget in = inputs.get(cat);
			if (in != null) {
				in.setVisible(false);
				in.setFocused(false);
			}
		}

		// волны от кликов
		for (Ripple r : ripples) {
			if (r.panel != i) continue;
			float p = clamp01(r.age / 0.5f);
			float rad = 4 + 34 * Gfx.easeOut(p);
			Gfx.rrect(c, r.x - rad, r.y - rad, rad * 2, rad * 2, rad, Gfx.withAlpha(Gfx.accentB(), ea * 0.22f * (1f - p)));
		}
		c.disableScissor();

		// полоса прокрутки с плавным появлением
		barFade[i] += ((maxS > 0.5f && (hover || Math.abs(SCROLL[i] - scrollAnim[i]) > 0.5f) ? 1f : 0.35f) - barFade[i]) * Gfx.animK(dt, 10f);
		if (maxS > 0.5f) {
			float thumbH = Math.max(14f, viewH * (viewH / contentH));
			float thumbY = listTop + (viewH - thumbH) * (scrollAnim[i] / maxS);
			Gfx.rrect(c, x + w - 4, thumbY, 2, thumbH, 1, Gfx.withAlpha(Gfx.accentA(), ea * barFade[i]));
		}
	}

	/** Стрелка: открыто - вниз, свёрнуто - вправо; между состояниями плавная смена. */
	private void drawChevron(DrawContext c, int cx, int cy, float open, float e) {
		int down = Gfx.withAlpha(Gfx.textDim(), e * open);
		int right = Gfx.withAlpha(Gfx.textDim(), e * (1f - open));
		for (int j = 0; j < 4; j++) {
			if (open > 0.02f) {
				c.fill(cx - 3 + j, cy - 2 + j, cx - 2 + j, cy - 1 + j, down);
				c.fill(cx + 3 - j, cy - 2 + j, cx + 4 - j, cy - 1 + j, down);
			}
			if (open < 0.98f) {
				c.fill(cx - 2 + j, cy - 3 + j, cx - 1 + j, cy - 2 + j, right);
				c.fill(cx - 2 + j, cy + 3 - j, cx - 1 + j, cy + 4 - j, right);
			}
		}
	}

	/** Клик в списке работает только в видимой части панели. */
	private void addListHit(int i, Hit h) {
		int top = Math.max(h.y(), (int) viewTop[i]);
		int bottom = Math.min(h.y() + h.h(), (int) viewBot[i]);
		if (bottom - top <= 2) return;
		hits.add(new Hit(h.x(), top, h.w(), bottom - top, h.left(), h.right(), h.slider()));
	}

	private void drawFeatureRow(DrawContext c, int pi, Feature f, int px, int y, int pw, float e, int slide, int listTop, int listBottom) {
		int rx = px + 4 + slide, rw = pw - 12, rh = ROW_H - 2;
		if (y + rh < listTop || y > listBottom) return;

		boolean hover = mouseX >= px + 4 && mouseX < px + 4 + rw && mouseY >= Math.max(y, listTop) && mouseY < Math.min(y + rh, listBottom);
		f.hoverAnim += ((hover ? 1f : 0f) - f.hoverAnim) * Gfx.animK(dtFrame, 18f);
		if (hover) hoverDesc = f.description;

		float fl = flash.getOrDefault(f, 0f);
		if (fl > 0.01f) flash.put(f, Math.max(0f, fl - dtFrame * 2.6f));

		// мягкая подсветка включённого модуля и наведения
		if (f.anim > 0.02f && !f.alwaysOn) {
			Gfx.rrect(c, rx, y, rw, rh, 5, Gfx.withAlpha(Gfx.accentA(), e * 0.16f * f.anim));
		}
		if (f.hoverAnim > 0.02f) Gfx.rrect(c, rx, y, rw, rh, 5, Gfx.withAlpha(Gfx.ROW_HOVER, e * f.hoverAnim));
		if (fl > 0.01f) Gfx.rrect(c, rx, y, rw, rh, 5, Gfx.withAlpha(0xFFFFFFFF, e * fl * 0.35f));

		// акцентная полоска выезжает слева
		float barH = (rh - 6) * Math.max(f.anim, f.hoverAnim * 0.6f);
		if (barH > 0.5f) {
			c.fill(rx + 1, y + (int) ((rh - barH) / 2), rx + 3, y + (int) ((rh + barH) / 2), Gfx.withAlpha(Gfx.accentA(), e));
		}

		int nameCol = Gfx.lerp(Gfx.textDim(), Gfx.text(), f.alwaysOn ? 1f : Math.max(f.anim, f.hoverAnim * 0.7f));
		int tx = rx + 7 + (int) (f.hoverAnim * 2f);
		int pill = 24;
		int px2 = rx + rw - pill - 4;
		String name = fit(f.name, px2 - tx - (f.settings.isEmpty() ? 2 : 12));
		c.drawText(textRenderer, name, tx, y + 5, Gfx.withAlpha(nameCol, e), true);

		int ph = 12, py = y + (rh - ph) / 2;
		Runnable expand = () -> f.expanded = !f.expanded;
		Runnable ripple = () -> ripples.add(new Ripple(pi, mouseX, mouseY));

		if (f.alwaysOn) {
			String sign = f.expanded ? "-" : "+";
			c.drawText(textRenderer, sign, px2 + pill - 6, y + 5, Gfx.withAlpha(Gfx.accentB(), e), true);
			addListHit(pi, new Hit(rx, y, rw, rh, () -> { expand.run(); ripple.run(); }, () -> { expand.run(); ripple.run(); }, null));
			return;
		}

		int track = Gfx.lerp(Gfx.OFF, Gfx.accentA(), f.anim);
		Gfx.rrect(c, px2, py, pill, ph, 6, Gfx.withAlpha(track, e));
		float knob = 2 + (pill - ph) * f.anim;
		Gfx.rrect(c, px2 + knob, py + 2, 8, 8, 4, Gfx.withAlpha(0xFFFFFFFF, e));

		if (!f.settings.isEmpty()) {
			String sign = f.expanded ? "-" : "+";
			c.drawText(textRenderer, sign, px2 - 9, y + 5, Gfx.withAlpha(Gfx.textDim(), e), false);
		}
		addListHit(pi, new Hit(rx, y, rw, rh, () -> {
			f.toggle();
			flash.put(f, 1f);
			ripple.run();
		}, f.settings.isEmpty() ? null : () -> { expand.run(); ripple.run(); }, null));
	}

	private void drawSetting(DrawContext c, int pi, Setting s, int px, int pw, int y, float e, boolean interactive, int listTop, int listBottom) {
		int rx = px + 10, rw = pw - 24;
		if (y + s.height() < listTop || y > listBottom) return;

		if (s instanceof BoolSetting b) {
			b.anim += ((b.value ? 1f : 0f) - b.anim) * Gfx.animK(dtFrame, 14f);
			c.drawText(textRenderer, fit(b.name, rw - 26), rx, y + 4, Gfx.withAlpha(Gfx.textDim(), e), true);
			int pw2 = 20, ph = 10;
			int bx = rx + rw - pw2, by = y + 3;
			Gfx.rrect(c, bx, by, pw2, ph, 5, Gfx.withAlpha(Gfx.lerp(Gfx.OFF, Gfx.accentB(), b.anim), e));
			Gfx.rrect(c, bx + 1 + (pw2 - ph) * b.anim, by + 1, 8, 8, 4, Gfx.withAlpha(0xFFFFFFFF, e));
			if (interactive) {
				addListHit(pi, new Hit(rx - 2, y, rw + 4, s.height(), () -> {
					b.value = !b.value;
					ripples.add(new Ripple(pi, mouseX, mouseY));
				}, null, null));
			}
		} else if (s instanceof NumSetting n) {
			String v = n.display();
			int vw = textRenderer.getWidth(v);
			c.drawText(textRenderer, fit(n.name, rw - vw - 6), rx, y + 3, Gfx.withAlpha(Gfx.textDim(), e), true);
			c.drawText(textRenderer, v, rx + rw - vw, y + 3, Gfx.withAlpha(Gfx.text(), e), true);

			int ty = y + 16;
			boolean over = mouseX >= rx - 2 && mouseX < rx + rw + 2 && mouseY >= y + 10 && mouseY < y + 26;
			boolean act = dragging == n;
			Gfx.rrect(c, rx, ty, rw, 4, 2, Gfx.withAlpha(Gfx.OFF, e));
			float fw = Math.max(4f, rw * n.fraction());
			int fill = n.hue ? Gfx.hsb((float) (n.value / 360.0), 0.8f, 1f) : Gfx.accentB();
			if (n.hue) {
				Gfx.rrect(c, rx, ty, fw, 4, 2, Gfx.withAlpha(fill, e));
			} else {
				Gfx.rrect(c, rx, ty, fw, 4, 2, Gfx.withAlpha(Gfx.lerp(Gfx.accentA(), fill, n.fraction()), e));
			}
			int kr = act ? 5 : over ? 4 : 3;
			Gfx.rrect(c, rx + fw - kr, ty + 2 - kr, kr * 2, kr * 2, kr, Gfx.withAlpha(0xFFFFFFFF, e));
			if (interactive) addListHit(pi, new Hit(rx - 2, y + 10, rw + 4, 16, null, null, n));
		} else if (s instanceof BindSetting bs) {
			boolean ls = listening == bs;
			String label = ls ? "нажмите клавишу" : bs.display();
			int bw = Math.max(36, Math.min(textRenderer.getWidth(label) + 10, rw - 40));
			label = fit(label, bw - 8);
			c.drawText(textRenderer, fit(bs.name, rw - bw - 6), rx, y + 5, Gfx.withAlpha(Gfx.textDim(), e), true);
			int bx = rx + rw - bw, by = y + 1;
			Gfx.rrect(c, bx, by, bw, 14, 4, Gfx.withAlpha(ls ? Gfx.accentA() : Gfx.header(), e));
			c.drawText(textRenderer, label, bx + (bw - textRenderer.getWidth(label)) / 2, by + 3, Gfx.withAlpha(Gfx.text(), e), true);
			if (interactive) {
				addListHit(pi, new Hit(bx, y, bw, 16, () -> listening = ls ? null : bs, () -> { bs.key = -1; listening = null; }, null));
			}
		}
	}

	private void drawRipples(DrawContext c, float dt) {
		for (Ripple r : ripples) r.age += dt;
		ripples.removeIf(r -> r.age > 0.5f);
	}

	// ------------------------------------------------------------------ Friends / Marks / Configs

	private List<Entry> entries(Category cat) {
		List<Entry> out = new ArrayList<>();
		switch (cat) {
			case FRIENDS -> {
				Set<String> online = Friends.onlineCache();
				for (String n : Friends.all()) {
					boolean on = online.contains(n.toLowerCase(Locale.ROOT));
					out.add(new Entry(n, on ? "в сети" : "не в сети", on ? 0xFF4ADE80 : Gfx.OFF, null, null, () -> Friends.remove(n)));
				}
			}
			case WAYPOINTS -> {
				String dimNow = client != null && client.world != null ? client.world.getRegistryKey().getValue().getPath() : "";
				for (Waypoints.Mark m : new ArrayList<>(Waypoints.LIST)) {
					String sub = m.x + " " + m.y + " " + m.z;
					if (client != null && client.player != null && m.dim.equals(dimNow)) {
						double dx = m.x + 0.5 - client.player.getX(), dz = m.z + 0.5 - client.player.getZ();
						sub += "  " + (int) Math.sqrt(dx * dx + dz * dz) + " m";
					}
					out.add(new Entry(m.name, sub, m.visible ? Gfx.accentB() : Gfx.OFF,
						m.visible ? "Скрыть" : "Показать",
						() -> { m.visible = !m.visible; Waypoints.save(); },
						() -> Waypoints.remove(m)));
				}
			}
			case CONFIGS -> {
				for (String n : profileCache) {
					out.add(new Entry(n, "профиль", Gfx.accentA(), "Загр.",
						() -> setStatus(Profiles.load(n) ? "Загружено: " + n : "Не удалось загрузить"),
						() -> { Profiles.delete(n); refreshProfiles(); }));
				}
			}
			default -> {}
		}
		return out;
	}

	private String hint(Category cat) {
		return switch (cat) {
			case FRIENDS -> "Ник друга";
			case WAYPOINTS -> "Название метки";
			case CONFIGS -> "Имя профиля";
			default -> "";
		};
	}

	private String addLabel(Category cat) {
		return cat == Category.CONFIGS ? "Сохр." : "+";
	}

	private void submit(Category cat) {
		TextFieldWidget input = inputs.get(cat);
		if (input == null) return;
		String t = input.getText().trim();
		switch (cat) {
			case FRIENDS -> {
				if (t.isEmpty()) return;
				setStatus(Friends.add(t) ? "Друг добавлен" : "Уже в списке");
			}
			case WAYPOINTS -> {
				if (client == null || client.player == null || client.world == null) {
					setStatus("Зайдите в мир");
					return;
				}
				String name = t.isEmpty() ? "Метка " + (Waypoints.LIST.size() + 1) : t;
				Waypoints.add(name, client.player.getBlockX(), client.player.getBlockY(), client.player.getBlockZ(),
					client.world.getRegistryKey().getValue().getPath());
				setStatus("Метка добавлена");
			}
			case CONFIGS -> {
				String name = Profiles.sanitize(t.isEmpty() ? "config" : t);
				Config.save();
				Profiles.save(name);
				refreshProfiles();
				setStatus("Сохранено: " + name);
			}
			default -> { return; }
		}
		input.setText("");
	}

	private void drawCustom(DrawContext c, int pi, Category cat, int px, int pw, float cy, List<Entry> entries, float e, int listTop, int listBottom) {
		TextFieldWidget input = inputs.get(cat);
		int rx = px + 4, rw = pw - 12;
		int y = (int) cy;

		int bw = textRenderer.getWidth(addLabel(cat)) + 12;
		boolean visible = y + INPUT_H > listTop && y < listBottom;
		if (input != null) {
			input.setVisible(visible);
			if (!visible) input.setFocused(false);
			input.setX(rx + 2);
			input.setY(y + 4);
			input.setWidth(rw - bw - 8);
			if (visible) {
				input.render(c, mouseX, mouseY, 0f);
				if (input.getText().isEmpty() && !input.isFocused()) {
					c.drawText(textRenderer, fit(hint(cat), rw - bw - 14), rx + 8, y + 7, Gfx.withAlpha(Gfx.textDim(), e), false);
				}
			}
		}
		int bx = rx + rw - bw - 2;
		boolean hover = mouseX >= bx && mouseX < bx + bw && mouseY >= y + 3 && mouseY < y + 19;
		Gfx.rrect(c, bx, y + 3, bw, 16, 5, Gfx.withAlpha(hover ? Gfx.accentA() : Gfx.header(), e));
		c.drawText(textRenderer, addLabel(cat), bx + 6, y + 7, Gfx.withAlpha(Gfx.text(), e), true);
		addListHit(pi, new Hit(bx, y + 3, bw, 16, () -> {
			submit(cat);
			ripples.add(new Ripple(pi, mouseX, mouseY));
		}, null, null));
		y += INPUT_H;

		if (entries.isEmpty()) {
			c.drawText(textRenderer, "Пока пусто", rx + 8, y + 4, Gfx.withAlpha(Gfx.textDim(), e), true);
			return;
		}
		int n = 0;
		for (Entry en : entries) {
			drawEntry(c, pi, en, px, pw, y, e, n);
			y += ENTRY_H;
			n++;
		}
	}

	private void drawEntry(DrawContext c, int pi, Entry en, int px, int pw, int y, float e, int n) {
		int rx = px + 4, rw = pw - 12, rh = ENTRY_H - 2;
		if (y + rh < viewTop[pi] || y > viewBot[pi]) return;

		float in = clamp01(open * 2f - n * 0.08f);
		int slide = (int) ((1f - Gfx.easeOut(in)) * 12f);
		e *= in;
		rx += slide;

		Gfx.rrect(c, rx, y, rw, rh, 5, Gfx.withAlpha(0x30FFFFFF, e));
		Gfx.rrect(c, rx + 4, y + 8, 6, 6, 3, Gfx.withAlpha(en.dot(), e));

		int xw = 14, xx = rx + rw - xw - 3, by = y + 4, bh = 14;
		int actW = en.act() != null ? textRenderer.getWidth(en.actLabel()) + 10 : 0;
		int textMax = rw - 16 - xw - actW - 10;
		c.drawText(textRenderer, fit(en.title(), textMax), rx + 14, y + 3, Gfx.withAlpha(Gfx.text(), e), true);
		c.drawText(textRenderer, fit(en.sub(), textMax), rx + 14, y + 13, Gfx.withAlpha(Gfx.textDim(), e), false);

		boolean hx = mouseX >= xx && mouseX < xx + xw && mouseY >= by && mouseY < by + bh;
		Gfx.rrect(c, xx, by, xw, bh, 4, Gfx.withAlpha(hx ? 0xFFEF4444 : Gfx.header(), e));
		c.drawText(textRenderer, "x", xx + 5, by + 3, Gfx.withAlpha(Gfx.text(), e), true);
		addListHit(pi, new Hit(xx, by, xw, bh, en.remove(), null, null));

		if (en.act() != null) {
			int ax = xx - actW - 3;
			boolean ha = mouseX >= ax && mouseX < ax + actW && mouseY >= by && mouseY < by + bh;
			Gfx.rrect(c, ax, by, actW, bh, 4, Gfx.withAlpha(ha ? Gfx.accentA() : Gfx.header(), e));
			c.drawText(textRenderer, en.actLabel(), ax + 5, by + 3, Gfx.withAlpha(Gfx.text(), e), true);
			addListHit(pi, new Hit(ax, by, actW, bh, en.act(), null, null));
		}
	}

	// ------------------------------------------------------------------ input

	private void applySlider(NumSetting n, Hit hit, double mouseX) {
		int rx = hit.x() + 2, rw = hit.w() - 4;
		double t = (mouseX - rx) / rw;
		n.set(n.min + (n.max - n.min) * Math.max(0, Math.min(1, t)));
	}

	private boolean anyInputFocused() {
		for (TextFieldWidget f : inputs.values()) if (f.isVisible() && f.isFocused()) return true;
		return false;
	}

	private void unfocusInputs() {
		for (TextFieldWidget f : inputs.values()) f.setFocused(false);
	}

	@Override
	public boolean mouseClicked(double mx, double my, int button) {
		if (closing) return true;
		BindSetting before = listening;

		// поле поиска и поля ввода обрабатывают фокус сами
		if (search.isMouseOver(mx, my)) {
			unfocusInputs();
			listening = null;
			return super.mouseClicked(mx, my, button);
		}
		for (TextFieldWidget f : inputs.values()) {
			if (f.isVisible() && f.isMouseOver(mx, my)) {
				search.setFocused(false);
				for (TextFieldWidget o : inputs.values()) if (o != f) o.setFocused(false);
				listening = null;
				return super.mouseClicked(mx, my, button);
			}
		}
		search.setFocused(false);
		unfocusInputs();

		for (int i = hits.size() - 1; i >= 0; i--) {
			Hit h = hits.get(i);
			if (!h.contains(mx, my)) continue;
			if (button == 0) {
				if (h.slider() != null) {
					dragging = h.slider();
					dragHit = h;
					applySlider(dragging, dragHit, mx);
				} else if (h.left() != null) {
					h.left().run();
				}
			} else if (button == 1 && h.right() != null) {
				h.right().run();
			}
			if (before != null && listening == before) listening = null;
			return true;
		}
		listening = null;
		return super.mouseClicked(mx, my, button);
	}

	@Override
	public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
		if (dragging != null && dragHit != null && button == 0) {
			applySlider(dragging, dragHit, mx);
			return true;
		}
		return super.mouseDragged(mx, my, button, dx, dy);
	}

	@Override
	public boolean mouseReleased(double mx, double my, int button) {
		if (dragging != null) {
			dragging = null;
			dragHit = null;
			Config.save();
		}
		return super.mouseReleased(mx, my, button);
	}

	@Override
	public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
		// колесо над ползунком меняет значение
		for (int i = hits.size() - 1; i >= 0; i--) {
			Hit h = hits.get(i);
			if (h.slider() != null && h.contains(mx, my)) {
				NumSetting n = h.slider();
				double st = n.step > 0 ? n.step : (n.max - n.min) / 50.0;
				n.set(n.value + Math.signum(vertical) * st);
				return true;
			}
		}
		boolean shift = org.lwjgl.glfw.GLFW.glfwGetKey(client.getWindow().getHandle(), GLFW.GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS;
		if (!shift) {
			for (int i = 0; i < N; i++) {
				if (mx >= pX[i] && mx < pX[i] + pW[i] && my >= viewTop[i] && my < viewBot[i]) {
					SCROLL[i] -= (float) vertical * 22f;
					return true;
				}
			}
		}
		panOff += (float) vertical * 40f;
		return true;
	}

	@Override
	public boolean charTyped(char chr, int modifiers) {
		if (swallowSlash) {
			swallowSlash = false;
			if (chr == '/') return true;
		}
		return super.charTyped(chr, modifiers);
	}

	private boolean swallowSlash;

	@Override
	public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
		if (listening != null) {
			if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
				listening = null;
				return true;
			}
			listening.key = (keyCode == GLFW.GLFW_KEY_BACKSPACE || keyCode == GLFW.GLFW_KEY_DELETE) ? -1 : keyCode;
			listening = null;
			Config.save();
			return true;
		}
		if (search.isFocused()) {
			if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
				if (searching()) search.setText("");
				search.setFocused(false);
				return true;
			}
			if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
				search.setFocused(false);
				return true;
			}
			return super.keyPressed(keyCode, scanCode, modifiers);
		}
		if (anyInputFocused()) {
			for (Map.Entry<Category, TextFieldWidget> en : inputs.entrySet()) {
				TextFieldWidget f = en.getValue();
				if (!f.isFocused()) continue;
				if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
					submit(en.getKey());
					return true;
				}
				if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
					f.setFocused(false);
					return true;
				}
			}
			return super.keyPressed(keyCode, scanCode, modifiers);
		}
		if (keyCode == GLFW.GLFW_KEY_SLASH) {
			setFocused(search);
			search.setFocused(true);
			swallowSlash = true;
			return true;
		}
		if (keyCode == dev.black.client.Keys.gui()) {
			close();
			return true;
		}
		return super.keyPressed(keyCode, scanCode, modifiers);
	}
}
