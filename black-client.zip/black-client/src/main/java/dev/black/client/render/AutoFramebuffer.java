package dev.black.client.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;

/** Фреймбуфер, который подстраивается под размер основного (порт AutoResizingFramebuffer из skycore). */
public final class AutoFramebuffer extends Framebuffer {
	public AutoFramebuffer(boolean useDepth) {
		super(useDepth);
	}

	public void setup(boolean clear) {
		resizeFramebuffer();
		setClearColor(0.0F, 0.0F, 0.0F, 0.0F);
		if (clear) clear();
		beginWrite(false);
	}

	public void stop() {
		endWrite();
		MinecraftClient.getInstance().getFramebuffer().beginWrite(false);
	}

	public void resizeTo(int width, int height) {
		int w = Math.max(1, width), h = Math.max(1, height);
		if (textureWidth == w && textureHeight == h) return;
		resize(w, h);
	}

	private void resizeFramebuffer() {
		Framebuffer main = MinecraftClient.getInstance().getFramebuffer();
		if (textureWidth == main.textureWidth && textureHeight == main.textureHeight) return;
		initFbo(Math.max(1, main.textureWidth), Math.max(1, main.textureHeight));
	}
}
