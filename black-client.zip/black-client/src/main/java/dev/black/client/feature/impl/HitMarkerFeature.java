package dev.black.client.feature.impl;

import dev.black.client.feature.Category;
import dev.black.client.feature.Feature;
import dev.black.client.feature.setting.BoolSetting;
import dev.black.client.feature.setting.NumSetting;
import dev.black.client.gui.Gfx;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;

/** Крестик у прицела в момент удара. Только отображение, механику удара не меняет. */
public class HitMarkerFeature extends Feature {
	public final NumSetting size = add(new NumSetting("Size", 7, 3, 16, 1, "px"));
	public final NumSetting duration = add(new NumSetting("Duration", 350, 100, 1000, 50, "ms"));
	public final BoolSetting redOnKill = add(new BoolSetting("Red on kill", true));

	private long hitAt;
	private boolean kill;

	public HitMarkerFeature() {
		super("Hit Marker", "Marker at the crosshair when you hit something", Category.VISUAL);
	}

	public void hit(Entity target) {
		hitAt = System.currentTimeMillis();
		kill = target instanceof LivingEntity le && le.getHealth() <= 2.0f;
	}

	public void draw(DrawContext c, MinecraftClient mc) {
		if (!enabled || hitAt == 0L) return;
		long age = System.currentTimeMillis() - hitAt;
		if (age > duration.value) return;
		float p = (float) (age / duration.value);
		int rgb = (kill && redOnKill.value) ? 0xFF4444 : (Gfx.text() & 0xFFFFFF);
		int color = (((int) (255 * (1f - p))) << 24) | rgb;
		int cx = mc.getWindow().getScaledWidth() / 2, cy = mc.getWindow().getScaledHeight() / 2;
		int inner = 3 + (int) (p * 3), len = (int) size.value;
		for (int sx = -1; sx <= 1; sx += 2) {
			for (int sy = -1; sy <= 1; sy += 2) {
				for (int i = 0; i < len; i++) {
					int x = cx + sx * (inner + i), y = cy + sy * (inner + i);
					c.fill(Math.min(x, x + 1), Math.min(y, y + 1), Math.max(x, x + 1), Math.max(y, y + 1), color);
				}
			}
		}
	}
}
