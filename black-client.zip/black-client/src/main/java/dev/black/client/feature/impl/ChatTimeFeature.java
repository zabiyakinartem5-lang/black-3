package dev.black.client.feature.impl;

import dev.black.client.feature.Category;
import dev.black.client.feature.Feature;
import dev.black.client.feature.setting.BoolSetting;

public class ChatTimeFeature extends Feature {
	public final BoolSetting seconds = add(new BoolSetting("Show seconds", false));

	public ChatTimeFeature() {
		super("Chat Time", "Timestamp before every chat message", Category.HUD);
	}
}
