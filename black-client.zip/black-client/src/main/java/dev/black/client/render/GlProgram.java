package dev.black.client.render;

import dev.black.client.BlackClient;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL20;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/** Простая GL-программа (вершинный + фрагментный шейдер из assets/blackclient/shaders/shadersystem). */
public final class GlProgram {
	private final int program;
	private final Map<String, Integer> locations = new HashMap<>();

	private GlProgram(int program) {
		this.program = program;
	}

	/** @return программа или null, если шейдер не скомпилировался / не слинковался. */
	public static GlProgram load(String fragmentFile, String vertexFile) {
		try {
			int vertex = compile(GL20.GL_VERTEX_SHADER, read(vertexFile));
			int fragment = compile(GL20.GL_FRAGMENT_SHADER, read(fragmentFile));
			int program = GL20.glCreateProgram();
			GL20.glAttachShader(program, vertex);
			GL20.glAttachShader(program, fragment);
			GL20.glBindAttribLocation(program, 0, "Position");
			GL20.glBindAttribLocation(program, 1, "UV0");
			GL20.glLinkProgram(program);
			GL20.glDeleteShader(vertex);
			GL20.glDeleteShader(fragment);
			if (GL20.glGetProgrami(program, GL20.GL_LINK_STATUS) == 0) {
				BlackClient.LOG.error("Shader link failed ({}): {}", fragmentFile, GL20.glGetProgramInfoLog(program));
				GL20.glDeleteProgram(program);
				return null;
			}
			return new GlProgram(program);
		} catch (Exception e) {
			BlackClient.LOG.error("Shader load failed: " + fragmentFile, e);
			return null;
		}
	}

	private static int compile(int type, String source) {
		int shader = GL20.glCreateShader(type);
		GL20.glShaderSource(shader, source);
		GL20.glCompileShader(shader);
		if (GL20.glGetShaderi(shader, GL20.GL_COMPILE_STATUS) == 0) {
			BlackClient.LOG.error("Shader compile failed: {}", GL20.glGetShaderInfoLog(shader));
		}
		return shader;
	}

	private static String read(String file) throws Exception {
		String path = "/assets/blackclient/shaders/shadersystem/" + file;
		try (InputStream in = GlProgram.class.getResourceAsStream(path)) {
			if (in == null) throw new IllegalStateException("Missing shader " + path);
			StringBuilder sb = new StringBuilder();
			try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
				String line;
				while ((line = r.readLine()) != null) sb.append(line).append('\n');
			}
			return sb.toString();
		}
	}

	private int loc(String name) {
		return locations.computeIfAbsent(name, n -> GL20.glGetUniformLocation(program, n));
	}

	public void use() {
		GL20.glUseProgram(program);
	}

	public void stop() {
		GL20.glUseProgram(0);
	}

	public void delete() {
		GL20.glDeleteProgram(program);
	}

	public void setInt(String name, int v) {
		GL20.glUniform1i(loc(name), v);
	}

	public void setFloat(String name, float v) {
		GL20.glUniform1f(loc(name), v);
	}

	public void setVec3(String name, float x, float y, float z) {
		GL20.glUniform3f(loc(name), x, y, z);
	}

	public void setVec4(String name, float x, float y, float z, float w) {
		GL20.glUniform4f(loc(name), x, y, z, w);
	}

	public void setMatrix4f(String name, Matrix4f m) {
		float[] values = new float[16];
		m.get(values);
		GL20.glUniformMatrix4fv(loc(name), false, values);
	}
}
