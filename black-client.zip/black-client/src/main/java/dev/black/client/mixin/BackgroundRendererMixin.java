package dev.black.client.mixin;

import dev.black.client.feature.Features;
import dev.black.client.feature.impl.ShaderSkyFeature;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Fog;
import net.minecraft.client.render.FogShape;
import net.minecraft.client.world.ClientWorld;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Туман для Atmosphere (режимы Clear и Override), как в skycore. */
@Mixin(BackgroundRenderer.class)
public class BackgroundRendererMixin {
	@Inject(method = "getFogColor", at = @At("HEAD"), cancellable = true, require = 0)
	private static void black$fogColor(Camera camera, float tickDelta, ClientWorld world, int clampedViewDistance,
									   float skyDarkness, CallbackInfoReturnable<Vector4f> cir) {
		ShaderSkyFeature a = Features.SHADER_SKY;
		if (!a.enabled || a.fogMode() != 2) return;
		int c = a.fogColorArgb();
		cir.setReturnValue(new Vector4f(((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f, 1f));
	}

	@Inject(method = "applyFog", at = @At("HEAD"), cancellable = true, require = 0)
	private static void black$applyFog(Camera camera, BackgroundRenderer.FogType fogType, Vector4f color, float viewDistance,
									   boolean thickenFog, float tickDelta, CallbackInfoReturnable<Fog> cir) {
		ShaderSkyFeature a = Features.SHADER_SKY;
		if (!a.enabled || a.fogMode() == 0) return;
		if (a.fogMode() == 1) { // Clear
			cir.setReturnValue(new Fog(Float.MAX_VALUE, Float.MAX_VALUE, FogShape.CYLINDER, color.x, color.y, color.z, color.w));
			return;
		}
		int c = a.fogColorArgb();
		cir.setReturnValue(new Fog(
			(float) a.fogStart.value * 42.67F, (float) a.fogEnd.value * 42.67F, FogShape.CYLINDER,
			((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f, 1f));
	}
}
