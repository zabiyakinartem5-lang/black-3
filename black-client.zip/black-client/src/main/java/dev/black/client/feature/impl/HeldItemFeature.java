package dev.black.client.feature.impl;

import dev.black.client.feature.Category;
import dev.black.client.feature.Feature;
import dev.black.client.feature.setting.NumSetting;

/** Предмет в руке: название, прочность или количество. */
public class HeldItemFeature extends Feature {
	public final NumSetting scale = add(new NumSetting("Scale", 1.0, 0.7, 1.6, 0.1, "x"));

	public HeldItemFeature() {
		super("Held Item", "Item in your hand with durability", Category.HUD);
	}
}
