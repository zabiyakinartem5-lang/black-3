package dev.black.client.feature.impl;

import dev.black.client.feature.Category;
import dev.black.client.feature.Feature;
import dev.black.client.feature.setting.NumSetting;

public class MotionBlurFeature extends Feature {
	public final NumSetting strength = add(new NumSetting("Strength", 60, 10, 90, 5, "%"));

	public MotionBlurFeature() {
		super("Motion Blur", "Smooth trails between frames (experimental)", Category.VISUAL);
	}
}
