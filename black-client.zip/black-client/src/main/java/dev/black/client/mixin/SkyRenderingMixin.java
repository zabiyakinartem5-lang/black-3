package dev.black.client.mixin;

import dev.black.client.render.SkyRenderer;
import net.minecraft.client.render.SkyRendering;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SkyRendering.class)
public class SkyRenderingMixin {
	@Inject(method = "renderSky", at = @At("HEAD"), cancellable = true, require = 0)
	private void black$replaceVanillaSky(float red, float green, float blue, CallbackInfo ci) {
		if (!SkyRenderer.shouldReplaceVanillaSky()) return;
		try {
			SkyRenderer.render();
			ci.cancel();
		} catch (Throwable ignored) {
		}
	}
}
