package dev.black.client.render;

import net.minecraft.client.gl.Framebuffer;
import org.joml.Matrix4f;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

import java.nio.FloatBuffer;

/** Помощники для полноэкранной пост-обработки (полноэкранный квад, blit, матрица). */
public final class PostFx {
	private static int vao, vbo;
	private static FloatBuffer buffer;

	private PostFx() {}

	/** Матрица, переводящая пиксельные координаты 0..w, 0..h в экран. */
	public static Matrix4f transform(int width, int height) {
		Matrix4f projection = new Matrix4f().setOrtho(0.0F, width, height, 0.0F, 1000.0F, 3000.0F);
		Matrix4f view = new Matrix4f().translation(0.0F, 0.0F, -2000.0F);
		return projection.mul(view);
	}

	public static void blit(Framebuffer source, Framebuffer destination, int width, int height) {
		int previousRead = GL30.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING);
		int previousDraw = GL30.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING);
		GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, source.fbo);
		GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, destination.fbo);
		GL30.glBlitFramebuffer(0, 0, width, height, 0, 0, width, height, GL11.GL_COLOR_BUFFER_BIT, GL11.GL_NEAREST);
		GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, previousRead);
		GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, previousDraw);
	}

	private static void ensure() {
		if (vao != 0) return;
		buffer = BufferUtils.createFloatBuffer(30);
		vao = GL30.glGenVertexArrays();
		vbo = GL15.glGenBuffers();
		GL30.glBindVertexArray(vao);
		GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo);
		GL20.glEnableVertexAttribArray(0);
		GL20.glVertexAttribPointer(0, 3, GL11.GL_FLOAT, false, 20, 0L);
		GL20.glEnableVertexAttribArray(1);
		GL20.glVertexAttribPointer(1, 2, GL11.GL_FLOAT, false, 20, 12L);
		GL30.glBindVertexArray(0);
		GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);
	}

	/**
	 * Рисует прямоугольник 0..width, 0..height с текстурными координатами.
	 * flipV=false - исходный порядок из skycore (изображение переворачивается), true - без переворота.
	 */
	public static void drawQuad(float width, float height, boolean flipV) {
		ensure();
		float top = flipV ? 1.0F : 0.0F, bottom = flipV ? 0.0F : 1.0F;
		float[] v = {
			0.0F, 0.0F, 0.0F, 0.0F, top,
			0.0F, height, 0.0F, 0.0F, bottom,
			width, height, 0.0F, 1.0F, bottom,
			0.0F, 0.0F, 0.0F, 0.0F, top,
			width, height, 0.0F, 1.0F, bottom,
			width, 0.0F, 0.0F, 1.0F, top
		};
		buffer.clear();
		buffer.put(v);
		buffer.flip();

		GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo);
		GL15.glBufferData(GL15.GL_ARRAY_BUFFER, buffer, GL15.GL_STREAM_DRAW);
		GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);

		int previousVao = GL30.glGetInteger(GL30.GL_VERTEX_ARRAY_BINDING);
		int previousBuffer = GL15.glGetInteger(GL15.GL_ARRAY_BUFFER_BINDING);
		GL30.glBindVertexArray(vao);
		GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo);
		GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 6);
		GL30.glBindVertexArray(previousVao);
		GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, previousBuffer);
	}
}
